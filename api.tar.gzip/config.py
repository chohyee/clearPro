#-*-coding:utf-8-*-
import time
import random

USER_APPID = 12345678
USER_UIN = 12345678

TVPC_URL = '.oss.vpc.tencentyun.com:8080/tvpc/api'
REGION = ['gz','bj']

QC_SECRET_KEY = 'kLkxxoTyHQOAmETWQ9g0882kGZgcPzQf'
QC_SECRET_ID  = 'AKIDDKnIcpaklcHk1DbOJPPPGvQjuuTyqQNB'


PARAM = {
    "Action": "RegisterInstancesFromForwardLBFourthListeners",
    "loadBalancerId": "lb-b72dk3n0",
    "Region":"gz",
    "backends": [
    {
        "port": 6666,
        "instanceId": "ins-5pytqz5s",
        "listenerId": "lbl-mdk35218",
        "weight": 10
    }
    ],
    "Timestamp":int(time.time()),
    "Nonce":random.randint(10000,99999)
}
