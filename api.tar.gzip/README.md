# clearPro
clear resource
